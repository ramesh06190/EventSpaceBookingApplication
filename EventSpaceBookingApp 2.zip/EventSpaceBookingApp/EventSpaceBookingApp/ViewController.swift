//
//  ViewController.swift
//  EventSpaceBookingApp
//
//  Created by Bhogireddy,Anjali on 4/23/23.
//

import UIKit

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var EmailOL: UITextField!
    
    
    @IBOutlet weak var password: UITextField!
    
    
    
    @IBOutlet weak var statusOL: UILabel!
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func loginbtn(_ sender: Any) {
    }
    
    @IBAction func createbtn(_ sender: Any) {
    }
    
    @IBAction func guestbtn(_ sender: Any) {
    }
    
}

